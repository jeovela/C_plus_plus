/**********************
 **Program Name: Menu.hpp
 **Author: Jeovani Vela
 **Date: 2/8/18
 **Description: This is the declaration file for the menu function.
**********************/
	

//this function displays a menu & returns a pointer to an array of type int
int* displayMenu();
