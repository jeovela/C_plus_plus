/**********************
 **Program Name: Menu.hpp
 **Author: Jeovani Vela
 **Date: 2/8/18
 **Description: This is the declaration file for the menu function.
**********************/
	
//function displays two options to user, start game or quit
int startMenu();

